﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;
using System.Text.RegularExpressions;

namespace JobProfile.Models
{
    public class NonNegativeAttribute : ValidationAttribute
    {

        /// <summary>
        /// Parameter 'value' will be set by the value entered 
        /// for the property from UI where the current attribute 
        /// is applied
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public override bool IsValid(object value)
        {
            if (Convert.ToInt32(value) < 0)
            {
                return false;
            }
            return true;
        }


    }

    public class Regrex : ValidationAttribute
    {
      
        public override bool IsValid(object value)
        {
            Regex re = new Regex("^([a-zA-Z]+( [a-zA-Z]+)+)$");
            if (re.IsMatch(Convert.ToString(value)))
            {
                return true;
            }
            return false;
        }

    }

    public class PhoneRegrex : ValidationAttribute
    {

        public override bool IsValid(object value)
        {
            Regex re = new Regex(@"\d{10}$");
            if (re.IsMatch(Convert.ToString(value)))
            {
                return true;
            }
            return false;
        }

    }

    public class EmailRegrex : ValidationAttribute
    {

        public override bool IsValid(object value)
        {
            Regex re = new Regex(@"^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$");
            if (re.IsMatch(Convert.ToString(value)))
            {
                return true;
            }
            return false;
        }

    }
}
