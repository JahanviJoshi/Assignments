﻿namespace JobProfile.Models
{
    public class DetailedList
    {
        public int PersonId { get; set; }
        public string FullName { get; set; }
        public string Address { get; set; }
        public string ContactNo { get; set; }
        public string Email { get; set; }
        public string ImageFile { get; set; }
        public string ProfileFile { get; set; }

        public string SscBoardName { get; set; }
        public double SscPercentage { get; set; }
        public int SscPassingYear { get; set; }
        public string HscBoardName { get; set; }
        public double? HscPercentage { get; set; }
        public int? HscPassingYear { get; set; }
        
        public string DegreeName { get; set; }
        public double? DegreePercentage { get; set; }
        public int? DegreePassingYear { get; set; }
        public string MastersName { get; set; }
        public double? MastersPercentage { get; set; }
        public int? MastersPassingYear { get; set; }
        public string HighestQuaification { get; set; }

        public string WorkExperience { get; set; }
        public string Companies { get; set; }
        public string ProjectInfo { get; set; }

    }
}
