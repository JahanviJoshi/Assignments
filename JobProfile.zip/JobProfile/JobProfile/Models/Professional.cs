﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

#nullable disable

namespace JobProfile.Models
{
    public partial class Professional
    {
        
        public int Professionalid { get; set; }
     
        public int? Personalid { get; set; }
    
        public string Workexperience { get; set; }
       
        public string Companies { get; set; }
      
        public string Projects { get; set; }
        
        public virtual Personal Personal { get; set; }
    }
}
