﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

#nullable disable

namespace JobProfile.Models
{
    public partial class Education
    {
        
        public int Educationid { get; set; }
    
        public int? Personalid { get; set; }
        [Required]
        public string Sscboardname { get; set; }
       [Required]
        public double? Sscpercentage { get; set; }
       [Required]
        public int? Sscpassingyear { get; set; }
       [Required]
        public string Hscboardname { get; set; }
       [Required]
        public double? Hscpercentage { get; set; }
       [Required]
        public int? Hscpassingyear { get; set; }
       [Required]
        public string Degreename { get; set; }
       [Required]
        public double? Degreepercentage { get; set; }
       [Required]
        public int? Degreepassingyear { get; set; }
        [Required]
        public string Masterdegreename { get; set; }
        [Required]
        public double? Masterdegreepercentage { get; set; }
        [Required]
        public int? Masterdegreepassingyear { get; set; }
      
        public string Higestqualification { get; set; }
        

        public virtual Personal Personal { get; set; }
    }
}
