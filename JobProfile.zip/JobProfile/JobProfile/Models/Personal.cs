﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc;

#nullable disable

namespace JobProfile.Models
{
    public partial class Personal
    {
        public Personal()
        {
            Educations = new HashSet<Education>();
            Professionals = new HashSet<Professional>();
        }

        public int Personalid { get; set; }
        [Required(ErrorMessage = "Name is required.")]

        [Regrex]

        public string Fullname { get; set; }
        [Required(ErrorMessage = "Address is required.")]
        public string Address { get; set; }
        [Required(ErrorMessage = "Contactno is required.")]
        [PhoneRegrex(ErrorMessage ="Invalid Format!")]

        public string Contactno { get; set; }
        [Required(ErrorMessage = "EmailId is required.")]
        [EmailRegrex]
        
        public string Emailid { get; set; }
      
        public string Imagefilepath { get; set; }
      
        public string Profilefilepath { get; set; }

        public virtual ICollection<Education> Educations { get; set; }
        public virtual ICollection<Professional> Professionals { get; set; }
    }
}
