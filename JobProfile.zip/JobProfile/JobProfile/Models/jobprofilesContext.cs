﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

#nullable disable

namespace JobProfile.Models
{
    public partial class jobprofilesContext : DbContext
    {
        public jobprofilesContext()
        {
        }

        public jobprofilesContext(DbContextOptions<jobprofilesContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Education> Educations { get; set; }
        public virtual DbSet<Personal> Personals { get; set; }
        public virtual DbSet<Professional> Professionals { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
                optionsBuilder.UseSqlServer("Data Source=.;Initial Catalog=jobprofiles;Integrated Security=SSPI");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Education>(entity =>
            {
                entity.ToTable("Education");

                entity.Property(e => e.Educationid).HasColumnName("educationid");

                entity.Property(e => e.Degreename)
                    .HasMaxLength(100)
                    .IsUnicode(false)
                    .HasColumnName("degreename");

                entity.Property(e => e.Degreepassingyear).HasColumnName("degreepassingyear");

                entity.Property(e => e.Degreepercentage).HasColumnName("degreepercentage");

                entity.Property(e => e.Higestqualification)
                    .HasMaxLength(200)
                    .IsUnicode(false)
                    .HasColumnName("higestqualification");

                entity.Property(e => e.Hscboardname)
                    .HasMaxLength(100)
                    .IsUnicode(false)
                    .HasColumnName("hscboardname");

                entity.Property(e => e.Hscpassingyear).HasColumnName("hscpassingyear");

                entity.Property(e => e.Hscpercentage).HasColumnName("hscpercentage");

                entity.Property(e => e.Masterdegreename)
                    .HasMaxLength(100)
                    .IsUnicode(false)
                    .HasColumnName("masterdegreename");

                entity.Property(e => e.Masterdegreepassingyear).HasColumnName("masterdegreepassingyear");

                entity.Property(e => e.Masterdegreepercentage).HasColumnName("masterdegreepercentage");

                entity.Property(e => e.Personalid).HasColumnName("personalid");

                entity.Property(e => e.Sscboardname)
                    .HasMaxLength(100)
                    .IsUnicode(false)
                    .HasColumnName("sscboardname");

                entity.Property(e => e.Sscpassingyear).HasColumnName("sscpassingyear");

                entity.Property(e => e.Sscpercentage).HasColumnName("sscpercentage");

                entity.HasOne(d => d.Personal)
                    .WithMany(p => p.Educations)
                    .HasForeignKey(d => d.Personalid)
                    .HasConstraintName("FK__Education__perso__36B12243");
            });

            modelBuilder.Entity<Personal>(entity =>
            {
                entity.ToTable("Personal");

                entity.Property(e => e.Personalid).HasColumnName("personalid");

                entity.Property(e => e.Address)
                    .HasMaxLength(250)
                    .IsUnicode(false);

                entity.Property(e => e.Contactno)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.Emailid)
                    .HasMaxLength(250)
                    .IsUnicode(false);

                entity.Property(e => e.Fullname)
                    .HasMaxLength(250)
                    .IsUnicode(false)
                    .HasColumnName("fullname");

                entity.Property(e => e.Imagefilepath)
                    .HasMaxLength(250)
                    .IsUnicode(false)
                    .HasColumnName("imagefilepath");

                entity.Property(e => e.Profilefilepath)
                    .HasMaxLength(250)
                    .IsUnicode(false)
                    .HasColumnName("profilefilepath");
            });

            modelBuilder.Entity<Professional>(entity =>
            {
                entity.ToTable("Professional");

                entity.Property(e => e.Professionalid).HasColumnName("professionalid");

                entity.Property(e => e.Companies)
                    .HasMaxLength(100)
                    .IsUnicode(false)
                    .HasColumnName("companies");

                entity.Property(e => e.Personalid).HasColumnName("personalid");

                entity.Property(e => e.Projects)
                    .HasMaxLength(500)
                    .IsUnicode(false)
                    .HasColumnName("projects");

                entity.Property(e => e.Workexperience)
                    .HasMaxLength(400)
                    .IsUnicode(false)
                    .HasColumnName("workexperience");

                entity.HasOne(d => d.Personal)
                    .WithMany(p => p.Professionals)
                    .HasForeignKey(d => d.Personalid)
                    .HasConstraintName("FK__Professio__perso__398D8EEE");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
