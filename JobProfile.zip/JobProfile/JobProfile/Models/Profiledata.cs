﻿using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Http;

namespace JobProfile.Models
{
    public class Profiledata
    {
        [Display(Name = "Image")]
        public IFormFile ProfilePicture { get; set; }
        public string ProfileUploadStatus { get; set; }
        public string ProfileFileName { get; set; }

        public IFormFile Resume { get; set; }
        public string ResumeUploadStatus { get; set; }
        public string ResumeFileName { get; set; }
    }
}
