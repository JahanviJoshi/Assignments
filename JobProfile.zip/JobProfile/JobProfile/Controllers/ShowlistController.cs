﻿using System.Collections.Generic;
using System.Linq;
using JobProfile.Models;
using JobProfile.Services;
using Microsoft.AspNetCore.Mvc;

namespace JobProfile.Controllers
{
    public class ShowlistController : Controller
    {
        private readonly IService<Personal, int> personserv;
        private readonly IService<Education, int> educaserv;
        private readonly IService<Professional, int> profeser;

        public DetailedList DetailedList { get; private set; }

        public ShowlistController(IService<Personal, int> perser, IService<Education, int> eduser, IService<Professional, int> proserv)
        {
            personserv = perser;
            educaserv = eduser;
            profeser = proserv;
        }
        public IActionResult Index()
        {
            var perservice = personserv.GetAsync().Result;
            var eduservice = educaserv.GetAsync().Result;

            var res = from g in perservice
                      join d in eduservice on
                      g.Personalid equals d.Personalid
                      select new
                      {
                          FullName = g.Fullname,
                          ContactNo = g.Contactno,
                          Email = g.Emailid,
                          HighestQuaification = d.Higestqualification,
                          ImageFilePath = g.Imagefilepath,
                          PersonID = g.Personalid,

                      };
            List<individual> individualdata = new List<individual>();
            foreach (var d in res)
            {
                individualdata.Add(new individual() { FullName = d.FullName, ContactNo = d.ContactNo, Email = d.Email, HighestQuaification = d.HighestQuaification, Image = d.ImageFilePath, PersonID = d.PersonID });
            }

            return View(individualdata);
        }
        public IActionResult Details(int id)
        {
            DetailedList dl= new DetailedList();
            var result = personserv.GetByIdAsync(id).Result;
            dl.PersonId = result.Personalid;
            dl.FullName = result.Fullname;
            dl.ContactNo = result.Contactno;
            dl.Address = result.Address;
            dl.Email = result.Emailid;
            dl.ImageFile = result.Imagefilepath;
            dl.ProfileFile = result.Profilefilepath;

            var res = educaserv.GetByIdAsync(id).Result;
            dl.SscBoardName = res.Sscboardname;
            dl.SscPercentage = (double)res.Sscpercentage;
            dl.SscPassingYear = (int)res.Sscpassingyear;
            dl.HscBoardName= res.Hscboardname;
            dl.HscPercentage = res.Hscpercentage;
            dl.HscPassingYear = res.Hscpassingyear;
            
            dl.DegreePercentage = res.Degreepercentage;
           
            dl.DegreeName = res.Degreename;
           
            dl.DegreePassingYear = res.Degreepassingyear;
            dl.MastersName = res.Masterdegreename;
            dl.MastersPercentage = res.Masterdegreepercentage;
            dl.MastersPassingYear = res.Masterdegreepassingyear;

            var cat = profeser.GetByIdAsync(id).Result;
            dl.WorkExperience = cat.Workexperience;
            dl.Companies = cat.Companies;
            dl.ProjectInfo = cat.Projects;

            return View(dl);
        }

    }
}
