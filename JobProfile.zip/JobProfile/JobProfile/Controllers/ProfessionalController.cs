﻿using JobProfile.Models;
using JobProfile.SessionExtension;
using Microsoft.AspNetCore.Mvc;

namespace JobProfile.Controllers
{
    public class ProfessionalController : Controller
    {
        public IActionResult Create()
        {
            var res = HttpContext.Session.GetSessionData<Professional>("Professionalid");
            if (res == null)
            {
                var professionalInfo = new Professional();
                return View(professionalInfo);
            }
            return View(res);
        }
        [HttpPost]
        public IActionResult Create(Professional professional)
        {
            
                HttpContext.Session.SetSessionData<Professional>("Professionalid", professional);
                return RedirectToAction("Upload", "Upload");
            
           
        }
    }
}
