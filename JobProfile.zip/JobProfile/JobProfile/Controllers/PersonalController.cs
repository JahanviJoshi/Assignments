﻿using JobProfile.Models;
using JobProfile.Services;
using JobProfile.SessionExtension;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace JobProfile.Controllers
{
    public class PersonalController : Controller
    {
        private readonly IService<Personal, int> PerService;
        public PersonalController(IService<Personal, int> perser)
        {
            PerService = perser;
        }
        public IActionResult Index()
        {

            var cats = PerService.GetAsync().Result;
            return View(cats);
        }

        public IActionResult Create()
        {
           
                var res = HttpContext.Session.GetSessionData<Personal>("Personalid");
                if (res == null)
                {
                    var personal = new Personal();
                    return View(personal);
                }
                return View(res);
            
            

        }
        [HttpPost]
        public IActionResult Create(Personal personal)
        {
            if (ModelState.IsValid)
            {
                HttpContext.Session.SetSessionData<Personal>("Personalid", personal);
                //return RedirectToAction("Create", "Personal");
                return RedirectToAction("Create", "Eduction");
            }
            else
            {

                ViewBag.Message = "Wrong Data!!";
                return View(personal);
            }

        }

        //public IActionResult Validatename(string Name)
        //{
        //    int count = 0;

        //    foreach (char c in Name)
        //    {
        //        if (c == ' ')
        //        {
        //            count++;
        //            if (count == 2)
        //            {
        //                return Json(data: true);
        //            }

        //        }

        //    }

        //    return Json(data: "Not valid");

        //}

    }
   
}
