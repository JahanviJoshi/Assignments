﻿using JobProfile.Models;
using JobProfile.Services;
using JobProfile.SessionExtension;
using Microsoft.AspNetCore.Mvc;

namespace JobProfile.Controllers
{
    public class EductionController : Controller
    {
        private readonly IService<Education, int> eduService;
        public EductionController(IService<Education, int> eduser)
        {
            eduService = eduser;
        }
        public IActionResult Create()
        {
            var res = HttpContext.Session.GetSessionData<Education>("Educationid");
            if (res == null)
            {
                var education = new Education();
                return View(education);
            }
            return View(res);

        }
        [HttpPost]
        public IActionResult Create(Education education)
        {
            if (ModelState.IsValid)
            {
                HttpContext.Session.SetSessionData<Education>("Educationid", education);
                return RedirectToAction("Create", "Professional");
            }
            else
            {
                ViewBag["Message"] = "Wrong Data!!";
                return View(education);
            }
        }

    }
}
