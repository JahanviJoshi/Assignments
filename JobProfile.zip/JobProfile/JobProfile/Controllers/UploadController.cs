﻿using System.IO;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using JobProfile.Models;
using JobProfile.Services;
using JobProfile.SessionExtension;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace JobProfile.Controllers
{
    public class UploadController : Controller
    {
        private readonly IService<Personal, int> Perserv;
        private readonly IService<Education, int> EduServ;
        private readonly IService<Professional, int> ProServ;
        IWebHostEnvironment hostEnvironment;

        public UploadController(IService<Personal, int> PerService, IService<Education, int> EduService, IService<Professional, int> ProService, IWebHostEnvironment hostEnvironment)
        {
            Perserv = PerService;
            EduServ = EduService;
            ProServ = ProService;
            this.hostEnvironment = hostEnvironment;
        }

        public IActionResult Upload()
        {
            Profiledata data = new Profiledata();
            return View(data);
        }

        [HttpPost]
        public async Task<IActionResult> Upload(Profiledata data)
        {
            // REad the Current Directtory that is mapped with WebServer
            // var folder = Path.Combine(Directory.GetCurrentDirectory(), "UploadedImages");
            // Get the File Objet

            IFormFile file = data.ProfilePicture;
            IFormFile Resume = data.Resume;

            // Process It
            // Always Check Length of file

            // if()
            if (file.Length > 0)
            {
                // REad the Uploaded File Name
                var postedFileName = ContentDispositionHeaderValue
                  .Parse(file.ContentDisposition)
                    .FileName.Trim('"');

                var resumeFileName = ContentDispositionHeaderValue
                .Parse(Resume.ContentDisposition)
                  .FileName.Trim('"');


                FileInfo fileInfo = new FileInfo(postedFileName);
                FileInfo fileInfonew = new FileInfo(resumeFileName);


                if (fileInfo.Extension == ".jpg" || fileInfo.Extension == ".png")
                {
                    var finalPath = Path.Combine(hostEnvironment.WebRootPath, "images", postedFileName);
                    using (var fs = new FileStream(finalPath, FileMode.Create))
                    {
                        // Create a File into the folder
                        await file.CopyToAsync(fs);
                    }
                    data.ProfileFileName = @$"~/images/{file.FileName}";
                    data.ProfileUploadStatus = "File is Uploaded Successfully";
                }
                else
                {
                    data.ProfileUploadStatus = "Failed to Upload Profile Picture......";
                    return View(data);
                }

                if (fileInfonew.Extension == ".pdf")
                {

                    var finalPath = Path.Combine(hostEnvironment.WebRootPath, "PDF", resumeFileName);
                    using (var fs = new FileStream(finalPath, FileMode.Create))
                    {
                        // Create a File into the folder
                        await Resume.CopyToAsync(fs);
                    }
                    data.ResumeFileName = @$"~/PDF/{Resume.FileName}";
                    data.ResumeUploadStatus = "Resume Uploded Successfully";
                }
                else
                {
                    data.ResumeUploadStatus = "Failed to Upload Resume......";
                    return View(data);
                }
            }
            else
            {
                return RedirectToAction("FileUpload");
            }


            var person = HttpContext.Session.GetSessionData<Personal>("Personalid");
            var education = HttpContext.Session.GetSessionData<Education>("Educationid");
            var professional = HttpContext.Session.GetSessionData<Professional>("Professionalid");


            person.Imagefilepath = data.ProfileFileName;
            person.Profilefilepath = data.ResumeFileName;
            var res = Perserv.CreateAsync(person).Result;

            education.Personalid = res.Personalid;

            if (education.Masterdegreepassingyear != null)
            {
                education.Higestqualification = "Master";
            }
            else if (education.Degreepassingyear!= null)
            {
                education.Higestqualification = "Bachelor";
            }
            else if (education.Hscpassingyear != null)
            {
                education.Higestqualification= "HSC";
            }
            else
            {
                education.Higestqualification = "SSC";
            }

            var res1 = EduServ.CreateAsync(education).Result;
            professional.Personalid = res.Personalid;
            var res2 = ProServ.CreateAsync(professional).Result;

            


            HttpContext.Session.Remove("Personal");
            HttpContext.Session.Remove("Educational");
            HttpContext.Session.Remove("Professional");


            return RedirectToAction("Index","Personal");
        }
    }
}
