﻿using System.Text.Json;
using Microsoft.AspNetCore.Http;

namespace JobProfile.SessionExtension
{
    public static class SessionExtension
    {
        public static void SetSessionData<T>(this ISession session, string sessionKey, T sessionValue)
        {
            session.SetString(sessionKey, JsonSerializer.Serialize(sessionValue));
        }

        public static T GetSessionData<T>(this ISession session, string sessionKey)
        {
            var data = session.GetString(sessionKey);
            if (data == null)
            {
                return default(T);
            }
            else
            {
                return JsonSerializer.Deserialize<T>(data);
            }
        }
    }
}
