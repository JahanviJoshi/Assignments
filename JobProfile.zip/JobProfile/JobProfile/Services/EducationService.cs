﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using JobProfile.Models;
using Microsoft.EntityFrameworkCore;

namespace JobProfile.Services
{
    public class EducationService : IService<Education, int>
    {
        private readonly jobprofilesContext ctx;

        public EducationService(jobprofilesContext c)
        {
            ctx = c;
        }
        async Task<Education> IService<Education,int>.CreateAsync(Education entity)
        {
            try
            {
                var result = await ctx.Educations.AddAsync(entity);
                await ctx.SaveChangesAsync();
                return result.Entity;
            }
            catch (Exception ex)
            {

                Console.WriteLine(ex.Message);
                return null;
            }
        }

        async Task<Education> IService<Education, int>.DeleteAsync(int id)
        {
            try
            {
                var result = await ctx.Educations.FindAsync(id);
                if (result == null)
                {
                    return null;
                }
                ctx.Educations.Remove(result);
                await ctx.SaveChangesAsync();
                return result;
            }
            catch (Exception ex)
            {

                Console.WriteLine(ex.Message);
                return null;
            }
        }

        async Task<IEnumerable<Education>> IService<Education, int>.GetAsync()
        {
            try
            {
                var result = await ctx.Educations.ToListAsync();
                await ctx.SaveChangesAsync();
                return result;
            }
            catch (Exception ex)
            {

                Console.WriteLine(ex.Message);
                return null;
            }
        }

       async Task<Education> IService<Education, int>.GetByIdAsync(int id)
        {
            var res = await ctx.Educations.ToListAsync();
            var edu = res.Where(x => x.Personalid == id).FirstOrDefault();
            return edu;
        }

        async Task<Education> IService<Education, int>.UpdateAsync(int id, Education entity)
        {
            try
            {
                var result = await ctx.Educations.FindAsync(id);
                if (result == null)
                {
                    return null;
                }
                //result.PersonId = entity.PersonId;
                //result.SscboardName = entity.SscboardName;
                //result.Sscpercentage = entity.Sscpercentage;
                //result.HscboardName = entity.HscboardName;
                //result.Hscpercentage = entity.Hscpercentage;
                //result.DegreeUniversityName = entity.DegreeUniversityName;
                //result.DegreePercentage = entity.DegreePercentage;
                //result.MastersUniversityName = entity.MastersUniversityName;
                //result.MastersPercentage = entity.MastersPercentage;

                await ctx.SaveChangesAsync();
                return result;
            }
            catch (Exception ex)
            {

                Console.WriteLine(ex.Message);
                return null;
            }
        }
    }
}
