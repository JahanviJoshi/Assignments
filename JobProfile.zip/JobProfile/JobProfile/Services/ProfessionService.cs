﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using JobProfile.Models;
using Microsoft.EntityFrameworkCore;

namespace JobProfile.Services
{

    public class ProfessionService : IService<Professional, int>
    {
        private readonly jobprofilesContext ctx;

        public ProfessionService(jobprofilesContext c)
        {
            ctx = c;
        }

        async Task<Professional>IService<Professional , int> .CreateAsync(Professional entity)
        {
            try
            {
                var result = await ctx.Professionals.AddAsync(entity);
                await ctx.SaveChangesAsync();
                return result.Entity;
            }
            catch (Exception ex)
            {

                Console.WriteLine(ex.Message);
                return null;
            }
        }

        async Task<Professional> IService<Professional, int>.DeleteAsync(int id)
        {
            try
            {
                var result = await ctx.Professionals.FindAsync(id);
                if (result == null)
                {
                    return null;
                }
                ctx.Professionals.Remove(result);
                await ctx.SaveChangesAsync();
                return result;
            }
            catch (Exception ex)
            {

                Console.WriteLine(ex.Message);
                return null;
            }
        }

        async Task<IEnumerable<Professional>> IService<Professional, int>.GetAsync()
        {
            try
            {
                var result = await ctx.Professionals.ToListAsync();
                await ctx.SaveChangesAsync();
                return result;
            }
            catch (Exception ex)
            {

                Console.WriteLine(ex.Message);
                return null;
            }
        }

       async Task<Professional> IService<Professional, int>.GetByIdAsync(int id)
        {
            var res = await ctx.Professionals.ToListAsync();
            var edu = res.Where(x => x.Personalid == id).FirstOrDefault();
            return edu;
        }

       async Task<Professional> IService<Professional, int>.UpdateAsync(int id, Professional entity)
        {
            try
            {
                var result = await ctx.Professionals.FindAsync(id);
                if (result == null)
                {
                    return null;
                }
                //result.PersonId = entity.PersonId;
                //result.WorkExperience = entity.WorkExperience;
                //result.Companies = entity.Companies;
                //result.ProjectInfo = entity.ProjectInfo;
                await ctx.SaveChangesAsync();
                return result;
            }
            catch (Exception ex)
            {

                Console.WriteLine(ex.Message);
                return null;
            }

        }
    }
}
