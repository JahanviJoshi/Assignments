﻿using JobProfile.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace JobProfile.Services
{
    public class PersonalService : IService<Personal, int>
    {
        private readonly jobprofilesContext ctx;
        public PersonalService(jobprofilesContext c)
        {
            ctx = c;
        }

        async Task<Personal> IService<Personal , int>.CreateAsync(Personal entity)
        {
            try
            {
                var result = await ctx.Personals.AddAsync(entity);
                await ctx.SaveChangesAsync();
                return result.Entity;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return null;
            }
        }

        async Task<Personal> IService<Personal, int>.DeleteAsync(int id)
        { 
            try
            {
                var result = await ctx.Personals.FindAsync(id);
                if (result != null)
                {
                    return null;
                }
                ctx.Personals.Remove(result);
                await ctx.SaveChangesAsync();
                return result;
            }
            catch (Exception ex)
            {

                Console.WriteLine(ex.Message);
                return null;
            }
        }

        async Task<IEnumerable<Personal>> IService<Personal, int>.GetAsync()
        {
            try
            {
                var result = await ctx.Personals.ToListAsync();
                await ctx.SaveChangesAsync();
                return result;
            }
            catch (Exception ex)
            {

                Console.WriteLine(ex.Message);
                return null;
            }
        }

        async Task<Personal> IService<Personal, int>.GetByIdAsync(int id)
        {
            try
            {
                var result = await ctx.Personals.FindAsync(id);
                if (result == null)
                {
                    return null;
                }
                return result;
            }
            catch (Exception ex)
            {

                Console.WriteLine(ex.Message);
                return null;
            }
        }

        async Task<Personal> IService<Personal, int>.UpdateAsync(int id, Personal entity)
        {
            try
            {
                var result = await ctx.Personals.FindAsync(id);
                if (result == null)
                {
                    return null;
                }
                //add code
                //result.Personalid = entity.Personalid;
                //result.Address = entity.Address;
                await ctx.SaveChangesAsync();
                return result;
            }
            catch (Exception ex)
            {

                Console.WriteLine(ex.Message);
                return null;
            }

        }
    }
}
